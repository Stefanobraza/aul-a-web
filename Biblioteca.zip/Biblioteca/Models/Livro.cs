using System.ComponentModel.DataAnnotations;

namespace  Biblioteca.Models;

public class Livro
{
    public int id {get; set;} //vira a chave primaria 
    [Required,StringLength(150)]
    public string Tituulo {get; set;} = string.Empty;
    [Required , StringLength(100)]
    public string Autor{get; set; } = string.Empty;
    public int Ano{get; set;}
}