using Biblioteca.Models;
using Microsoft.EntityFrameworkCore;


namespace Biblioteca.Data;
public class BibliotecaContext : DbContext
{
    public BibliotecaContext(DbContextOptions<BibliotecaContext>options)
    : base (options){}
    
    public DbSet<Livro> livros => Set<Livro>();
}